Compile by
g++ *.cpp -IC:\mingw_dev_lib\include\SDL2 -IC:\mingw_dev_lib\include\SDL2_ttf -LC:\mingw_dev_lib\lib -w -lmingw32 -lSDL2main -lSDL2 -lSDL2_image -lSDL2_mixer -lSDL2_ttf

Run by
.\a.exe



Game Information:

The game has 2 modes hard and easy

You can select Hardmode by pressing the H key

You can select EasyMode by pressing the E key

You can shoot Lazers via the Z button

You can activate a timestop feature by pressing the M button, if your score is above 50

The up down left right arrow keys are for movement

You get 3 lifes, collision with objects will decrease you life so you must avoid them