--Delete from Users where UserID>6;


--select * from Departments
select * from Users

select * from UserDepartment


SELECT
    U.UserName AS Name,
    D.DeptName AS Department,
    U.UserID AS ID,
    U.UserDesignation AS Designation,
    U.ContactNumber AS [Contact Number],
    U.Email
FROM
    Users U
JOIN
    UserDepartment UD ON U.UserID = UD.UserID
JOIN
    Departments D ON UD.DeptID = D.DeptID;
