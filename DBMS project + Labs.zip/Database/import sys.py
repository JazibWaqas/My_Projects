import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout
from PyQt6.uic import loadUi  # Import the loadUi function

class MyWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Load the UI file
        self.ui = loadUi('Loginpage.ui')  # Replace 'my_ui_file.ui' with your UI file name

        # Set up the main window
        self.setWindowTitle('Loaded UI Example')
        self.setCentralWidget(self.ui)

def main():
    app = QApplication(sys.argv)
    window = MyWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
