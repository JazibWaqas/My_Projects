--1
select * from Products where ProductName = 'Tea'
--set identity_insert Products ON
INSERT INTO Products (ProductID, ProductName, CategoryID, UnitPrice)
VALUES (2050, 'Mountain Dew', 1, 10);

--2
INSERT INTO Products (ProductID, ProductName, CategoryID, UnitPrice)
VALUES (2051, 'Tea', 1, 10);

--3
UPDATE Products
SET UnitPrice = UnitPrice * 1.25
WHERE CategoryID = 1;

--4
INSERT INTO Categories (CategoryName)
VALUES ('Drinks');

--SELECT * FROM Categories WHERE CategoryName = 'Drinks';
--5
SELECT CategoryID
FROM Categories
WHERE CategoryName = 'Drinks';
UPDATE Products
SET CategoryID = 2
WHERE CategoryID = 1; 


--6
SELECT ProductID
FROM Products
WHERE CategoryID = 1;

UPDATE Products
SET CategoryID = 2 
WHERE CategoryID = 1; 

--7
SELECT TerritoryID
FROM EmployeeTerritories
WHERE EmployeeID = (SELECT EmployeeID FROM Employees WHERE LastName = 'King' AND FirstName = 'Robert');

DELETE FROM EmployeeTerritories
WHERE EmployeeID = (SELECT EmployeeID FROM Employees WHERE LastName = 'Davolio' AND FirstName = 'Nancy');

INSERT INTO EmployeeTerritories (EmployeeID, TerritoryID)
SELECT (SELECT EmployeeID FROM Employees WHERE LastName = 'Davolio' AND FirstName = 'Nancy'), TerritoryID
FROM EmployeeTerritories
WHERE EmployeeID = (SELECT EmployeeID FROM Employees WHERE LastName = 'King' AND FirstName = 'Robert');


--8
DELETE FROM Products
WHERE CategoryID = (SELECT CategoryID FROM Categories WHERE CategoryName = 'Seafood')
AND UnitPrice < 5;

--9
DELETE FROM Orders
WHERE CustomerID = 'ALFKI';

--10
DELETE FROM [Order Details]
WHERE OrderID IN (SELECT OrderID FROM Orders WHERE ShippedDate >= '1996-08-01' AND ShippedDate < '1996-09-01');

DELETE FROM Orders
WHERE ShippedDate >= '1996-08-01' AND ShippedDate < '1996-09-01';



