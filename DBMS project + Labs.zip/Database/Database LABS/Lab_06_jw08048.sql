--1
select * from Customers
--2
select OrderId, OrderDate, ShipCity, ShipCountry from orders
--3
select OrderId, OrderDate, CustomerID  from Orders where ShipCountry = 'Brazil'
--4
select OrderId, OrderDate, CustomerID  from Orders where ShipCountry = 'France' or ShipCountry ='Sweden'
--5
select OrderId, OrderDate,Freight,ShipCountry from Orders where (ShipCountry = 'France' or ShipCountry ='Sweden') and Freight>45
--6
select TitleOFCourtesy + ' ' + FirstName + ' '+ LastName as FullName, TitleofCourtesy from Employees
--7
select OrderId, OrderDate, ShipName, ShipAddress, ShipCity, ShipCountry from Orders where ShipAddress like '%box%' 
--8
select OrderId, CustomerID from Orders where CustomerId like 'A%I'
--9
select FirstName + ' ' + LastName as EmployeeName from Employees where DATEDIFF(year,HireDate,GetDate())>10
--10
select * , DATEDIFF(day,ShippedDate,OrderDate) from Orders
--11
select * from Customers where Fax IS null 
--12
select * from Products where QuantityPerUnit like '%box%'