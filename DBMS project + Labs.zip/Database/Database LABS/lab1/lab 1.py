import sys
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QFormLayout, QLabel, QLineEdit, QComboBox, QListWidget, \
    QPushButton, QCheckBox, QMessageBox, QHBoxLayout
from datetime import datetime

class DesktopForm(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Desktop Form in PyQt6")
        self.setGeometry(300, 75, 600, 500)

        self.layout = QVBoxLayout()

        # Name, ISBN, Purchased On input boxes
        self.name_input = QLineEdit()
        self.isbn_input = QLineEdit()
        self.purchased_on_input = QLineEdit()
        input_box_layout = QFormLayout()
        input_box_layout.addRow(QLabel("Name:"), self.name_input)
        input_box_layout.addRow(QLabel("ISBN:"), self.isbn_input)
        input_box_layout.addRow(QLabel("Purchased On:"), self.purchased_on_input)

        # Category Combo Box
        self.category_combo = QComboBox()
        self.category_combo.addItems(["Database Systems", "OOP", "Artificial Intelligence"])
        self.category_combo.currentTextChanged.connect(self.load_subcategories)

        # Subcategory Combo Box
        self.subcategory_combo = QComboBox()

        # Authors section
        authors_heading = QLabel("Authors")
        self.author_name_input = QLineEdit()  
        add_author_button = QPushButton("Add")
        author_input_layout = QHBoxLayout()
        author_input_layout.addWidget(QLabel("Author Name:"))
        author_input_layout.addWidget(self.author_name_input)  
        author_input_layout.addWidget(add_author_button)

        self.author_list = QListWidget()

        # Type and Issuance boxes
        self.type_layout = QVBoxLayout()
        self.book_type_textbook = QCheckBox("Text Book")
        self.book_type_reference = QCheckBox("Reference Book")
        self.book_type_journal = QCheckBox("Journal")
        # self.type_layout.addWidget(QLabel("Type:"))
        self.type_layout.addWidget(self.book_type_textbook)
        self.type_layout.addWidget(self.book_type_reference)
        self.type_layout.addWidget(self.book_type_journal)

        self.issuance_layout = QVBoxLayout()
        self.issuance_checkbox = QCheckBox("Issued")
        self.issued_by_input = QLineEdit()
        self.issued_on_input = QLineEdit()
        self.issuance_layout.addWidget(self.issuance_checkbox)
        self.issuance_layout.addWidget(QLabel("Issued By:"))
        self.issuance_layout.addWidget(self.issued_by_input)
        self.issuance_layout.addWidget(QLabel("Issued On:"))
        self.issuance_layout.addWidget(self.issued_on_input)

        self.form_layout = QFormLayout()

        add_author_button.clicked.connect(self.add_author)
        self.issuance_checkbox.toggled.connect(self.toggle_issuance_fields)

        
        self.form_layout.addRow(QLabel("Category:"), self.category_combo)
        self.form_layout.addRow(QLabel("Subcategory:"), self.subcategory_combo)
        self.form_layout.addRow(authors_heading)
        self.form_layout.addRow(author_input_layout)
        self.form_layout.addRow(self.author_list)


        type_and_issuance_layout = QHBoxLayout()
        type_column = QVBoxLayout()
        type_column.addWidget(QLabel("Type"))
        type_column.addLayout(self.type_layout)

        issuance_column = QVBoxLayout()
        issuance_column.addWidget(QLabel("Issuance"))
        issuance_column.addLayout(self.issuance_layout)

        type_and_issuance_layout.addLayout(type_column)
        type_and_issuance_layout.addLayout(issuance_column)

        self.form_layout.addRow(type_and_issuance_layout)

        self.ok_button = QPushButton("OK")
        self.close_button = QPushButton("Close")

        self.layout.addLayout(input_box_layout)
        self.layout.addLayout(self.form_layout)
        self.layout.addWidget(self.ok_button)
        self.layout.addWidget(self.close_button)

        self.setLayout(self.layout)

    def load_subcategories(self):
        category = self.category_combo.currentText()
        self.subcategory_combo.clear()
        if category == "Database Systems":
            self.subcategory_combo.addItems(["ERD", "SQL", "OLAP", "Data Mining"])
        elif category == "OOP":
            self.subcategory_combo.addItems(["C++", "Java"])
        elif category == "Artificial Intelligence":
            self.subcategory_combo.addItems(["Machine Learning", "Robotics", "Computer Vision"])

    def add_author(self):
        author_name = self.author_name_input.text().strip()
        if author_name:
            self.author_list.addItem(author_name)
            self.author_name_input.clear()

    def toggle_issuance_fields(self):
        enabled = self.issuance_checkbox.isChecked()
        self.issued_by_input.setEnabled(enabled)
        self.issued_on_input.setEnabled(enabled)

    def verify_conditions(self):
        name = self.name_input.text()
        isbn = self.isbn_input.text()
        purchased_date = self.purchased_on_input.text()
        error_messages = []

        # Condition 1: The ISBN should not be more than 12 characters long.
        if len(isbn) > 12:
            error_messages.append("ISBN should not exceed 12 characters.")

        # Condition 2: The 'Purchased on' date must be earlier than today.
        try:
            purchased_date = datetime.strptime(purchased_date, "%d/%m/%Y")  
            if purchased_date >= datetime.today():
                error_messages.append("Purchased date must be earlier than today.")
        except ValueError:
            error_messages.append("Invalid date format for 'Purchased on'.")

        # Condition 3: If the book is of the type 'Journal' it will have no author;
        # otherwise, it must have at least one author.
        if self.book_type_journal.isChecked() and self.author_list.count() > 0:
            error_messages.append("Journals should not have authors.")
        elif not self.book_type_journal.isChecked() and self.author_list.count() == 0:
            error_messages.append("The book must have at least one author.")

        # Condition 4: If the book is issued to someone, the 'Issued to' field must not
        # be empty, and the 'Issue date' field must be more than the 'Purchased On' field
        # but less than today's date.
        if self.issuance_checkbox.isChecked():
            issued_to = self.issued_by_input.text().strip()
            issued_date = self.issued_on_input.text()
            if not issued_to:
                error_messages.append("The 'Issued to' field must not be empty.")
            try:
                issued_date = datetime.strptime(issued_date, "%d/%m/%Y")  
                if issued_date <= purchased_date or issued_date > datetime.today():
                    error_messages.append("Invalid 'Issued On' date.")
            except ValueError:
                error_messages.append("Invalid date format for 'Issued On'.")

        if not error_messages:
            self.show_success_message()
        else:
            self.show_error_message("\n".join(error_messages))

    def show_success_message(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Icon.Information)
        msg.setText("Book added successfully!")
        msg.setWindowTitle("Success")
        msg.exec()

    def show_error_message(self, message):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Icon.Critical)
        msg.setText("Error(s) occurred:")
        msg.setInformativeText(message)
        msg.setWindowTitle("Error")
        msg.exec()

    def close_application(self):
        self.close()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = DesktopForm()

    window.ok_button.clicked.connect(window.verify_conditions)


    window.close_button.clicked.connect(window.close_application)

    window.show()
    sys.exit(app.exec())
