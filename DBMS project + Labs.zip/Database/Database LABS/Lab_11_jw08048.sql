--1
GO
CREATE VIEW ProductSummary AS
SELECT
    Products.ProductName,
    Suppliers.CompanyName AS SupplierName,
    Categories.CategoryName,
    Products.UnitPrice AS Price,
    COUNT(Orders.OrderID) AS NumberOfOrders,
    SUM([Order Details].Quantity) AS TotalQuantitySold
FROM
    Products
JOIN
    Suppliers ON Products.SupplierID = Suppliers.SupplierID
JOIN
    Categories ON Products.CategoryID = Categories.CategoryID
LEFT JOIN
    [Order Details] ON Products.ProductID = [Order Details].ProductID
LEFT JOIN
    Orders ON [Order Details].OrderID = Orders.OrderID
GROUP BY
    Products.ProductID, Products.ProductName, Suppliers.CompanyName, Categories.CategoryName, Products.UnitPrice;

--select * from ProductSummary

--2
GO
CREATE VIEW CustomerSummary AS
SELECT
    CONCAT(Employees.FirstName, ' ', Employees.LastName) AS EmployeeName,
    CONCAT(Managers.FirstName, ' ', Managers.LastName) AS ManagerName,
    DATEDIFF(YEAR, Employees.BirthDate, GETDATE()) AS Age,
    DATEDIFF(YEAR, Employees.HireDate, GETDATE()) AS YearsWithCompany,
    COUNT(Orders.OrderID) AS NumberOfOrdersProcessed
FROM
    Employees
LEFT JOIN
    Employees AS Managers ON Employees.ReportsTo = Managers.EmployeeID
LEFT JOIN
    Orders ON Employees.EmployeeID = Orders.EmployeeID
GROUP BY
    Employees.FirstName, Employees.LastName, Managers.FirstName, Managers.LastName, Employees.BirthDate, Employees.HireDate;

--select * from CustomerSummary

--3
CREATE PROCEDURE OfferDiscount
    @ProductID INT,
    @DiscountPercentage DECIMAL(5, 2)
AS
BEGIN
 -- (a) 
    UPDATE Products
    SET UnitPrice = UnitPrice - (UnitPrice * (@DiscountPercentage / 100))
    WHERE ProductID = @ProductID;

-- (b) 
    UPDATE [Order Details]
    SET UnitPrice = UnitPrice - (UnitPrice * (@DiscountPercentage / 100))
    FROM [Order Details]
    INNER JOIN Orders ON [Order Details].OrderID = Orders.OrderID
    WHERE [Order Details].ProductID = @ProductID
      AND Orders.ShippedDate IS NULL;
END;

Exec OfferDiscount 5,10.0;
select * from Products;
select * from Products;
select * from [Order Details];

--4

CREATE PROCEDURE DeleteEmployee
    @EmployeeID INT
AS
BEGIN
--(a)
    IF EXISTS (SELECT 1 FROM Employees WHERE EmployeeID = @EmployeeID AND ReportsTo IS NULL)
    BEGIN
        PRINT 'Error: Top managers cannot be deleted.';
        RETURN;
    END
--(b)
    IF EXISTS (SELECT 1 FROM Orders WHERE EmployeeID = @EmployeeID)
    BEGIN
        PRINT 'Error: Employee has worked on orders and cannot be deleted.';
        RETURN;
    END
--C(i)
    DELETE FROM EmployeeTerritories WHERE EmployeeID = @EmployeeID;

--(ii)
    IF EXISTS (SELECT 1 FROM Employees WHERE ReportsTo = @EmployeeID)
    BEGIN
        -- Set the manager of e1's subordinates as the manager of e1
        UPDATE Employees
        SET ReportsTo = (SELECT ReportsTo FROM Employees WHERE EmployeeID = @EmployeeID)
        WHERE ReportsTo = @EmployeeID;
    END

--(iii)
    DELETE FROM Employees WHERE EmployeeID = @EmployeeID;

    PRINT 'Employee deleted successfully.';
END;

EXEC DeleteEmployee @EmployeeID = 5;


--5
CREATE PROCEDURE CopyOrder
    @OrderID INT,
    @CustomerID VARCHAR(5)
AS
BEGIN
    DECLARE @NewOrderID INT;
    INSERT INTO Orders (CustomerID, OrderDate)
    VALUES (@CustomerID, GETDATE());

    SET @NewOrderID = SCOPE_IDENTITY();

    INSERT INTO [Order Details](OrderID, ProductID, Quantity, UnitPrice, Discount)
    SELECT
        @NewOrderID,
        ProductID,
        Quantity,
        UnitPrice,
        Discount
    FROM
        [Order Details]
    WHERE
        OrderID = @OrderID;

    PRINT 'Order copied successfully.';
END;


EXEC CopyOrder @OrderID = 10248, @CustomerID = 'ALFKI';