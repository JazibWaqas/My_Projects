--1
SELECT DISTINCT CustomerID
FROM Customers
WHERE CustomerID IN (SELECT CustomerID FROM Orders
WHERE OrderID IN (SELECT OrderID FROM [Order Details] 
WHERE ProductID IN (SELECT ProductID FROM Products
WHERE ProductID IN (SELECT ProductID FROM Products
WHERE UnitPrice > (SELECT AVG(UnitPrice) FROM Products)))));


--2
SELECT DISTINCT ContactName
FROM Customers
WHERE CustomerID IN (SELECT CustomerID FROM Orders
WHERE OrderID IN (SELECT OrderID FROM [Order Details]
WHERE ProductID IN (SELECT ProductID FROM Products
WHERE CategoryID = (SELECT CategoryID FROM Products
WHERE ProductName = 'Chai'))));

--3
SELECT ContactName, NumberOfOrders FROM (SELECT Customers.ContactName, (SELECT COUNT(Orders.OrderID) FROM Orders 
WHERE Orders.CustomerID = Customers.CustomerID) AS NumberOfOrders
FROM Customers) AS Subquery
WHERE NumberOfOrders =(SELECT MAX(NumberOfOrders) FROM (SELECT COUNT(Orders.OrderID) AS NumberOfOrders FROM Orders 
GROUP BY Orders.CustomerID) AS Subquery2);


--4
SELECT DISTINCT Customers.ContactName FROM Customers 
WHERE Customers.CustomerID IN (SELECT Orders.CustomerID FROM Orders 
WHERE Orders.OrderID IN (SELECT [Order Details].OrderID  FROM [Order Details] 
Where UnitPrice = (select MAX(UnitPrice) from [Order Details])))

--5
SELECT AVG(NumberOfProducts) AS AverageProductsPerOrder
FROM (SELECT OrderID, COUNT(*) AS NumberOfProducts FROM [Order Details]
GROUP BY OrderID) AS Subquery;

--6
SELECT CategoryName FROM Categories WHERE CategoryID IN
(SELECT CategoryID FROM Products GROUP BY CategoryID HAVING AVG(UnitPrice) > (SELECT AVG(UnitPrice) FROM Products));

--7
SELECT ProductName, UnitPrice FROM Products WHERE UnitPrice = (SELECT MAX(UnitPrice) FROM Products
WHERE UnitPrice < (SELECT MAX(UnitPrice) FROM Products));

--8
SELECT AVG(AverageOrderAmount) AS AverageOrderAmount
FROM (SELECT CustomerID, (SELECT SUM(UnitPrice * Quantity) FROM [Order Details] WHERE [Order Details].OrderID = Orders.OrderID) AS AverageOrderAmount FROM Orders 
WHERE Orders.CustomerID IN (SELECT CustomerID FROM Customers
WHERE Country = 'France')) AS Subquery;










