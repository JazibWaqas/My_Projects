--1
select count(OrderID) from Orders where YEAR(OrderDate)= 1998
--2
select sum(UnitsInStock) as TotalQuantity from Products 
--3
select sum(UnitsInStock*UnitPrice) as TotalPrice from Products 
--4
select Orders.OrderID,Orders.OrderDate,Products.ProductName from Orders,Products,[Order Details] where Orders.OrderID= [Order Details].OrderID and Products.ProductID= [Order Details].ProductID
--5
select Orders.OrderID, Orders.OrderDate, Products.ProductName, Categories.CategoryName from Orders,Products,Categories,[Order Details] where [Order Details].ProductID=Products.ProductID and 
Orders.OrderID=[Order Details].OrderID
and  Products.CategoryID= Categories.CategoryID and Categories.CategoryName='Beverages'
--6

SELECT Suppliers.CompanyName, COUNT(Products.ProductID) AS "No of Products" FROM Suppliers join Products  ON Suppliers.SupplierID = Products.SupplierID
GROUP BY Suppliers.CompanyName ORDER BY "No of Products" DESC;

--7
select Suppliers.CompanyName, Categories.CategoryName,COUNT(*) AS numofproducts,AVG(Products.UnitPrice),SUM(Products.UnitsInStock) from Products Products inner join 

Suppliers on Suppliers.SupplierID= Products.SupplierID inner join Categories on Categories.CategoryID= Products.CategoryID Group By Suppliers.CompanyName, Categories.CategoryName

--8
select Region.RegionDescription,count(*) AS No_of_Employees from Employees inner join EmployeeTerritories on Employees.EmployeeID = EmployeeTerritories.EmployeeID
inner join Territories on Territories.TerritoryID = EmployeeTerritories.TerritoryID 
inner join Region on Region.RegionID=Territories.RegionID 
Group By RegionDescription

--9
select OrderID,Sum((UnitPrice*Quantity)-Discount) from [Order Details] Group By OrderID

--10
select Categories.CategoryName, COUNT(*) AS num_products from Categories inner join Products ON Categories.CategoryID = Products.CategoryID Group By Categories.CategoryName

--11
select Customers.ContactName, Suppliers.CompanyName,count(Distinct orders.OrderID)
from Customers inner join Orders on Customers.CustomerID=Orders.CustomerID
inner join [Order Details] on [Order Details].OrderID=Orders.OrderID
inner join products on products.ProductID=[Order Details].ProductID
inner join Suppliers on Suppliers.SupplierID=Products.SupplierID group by Customers.ContactName, Suppliers.CompanyName order by Customers.ContactName, Suppliers.CompanyName

--12

select Employees.TitleOfCourtesy+' '+Employees.FirstName+' '+Employees.LastName As employee_name, YEAR(Orders.OrderDate) As OrderYear, COUNT(Orders.OrderID) As NumOrders from Employees
inner join Orders on Employees.EmployeeID = Orders.EmployeeID
group by Employees.TitleOfCourtesy+' '+Employees.FirstName+' '+Employees.LastName, YEAR(Orders.OrderDate) order by OrderYear, NumOrders

--13 

SELECT CONCAT(Employees.FirstName, ' ', Employees.LastName),CONCAT(Managers.FirstName, ' ', Managers.LastName),COUNT(Orders.OrderID) from Employees
left join Employees Managers ON Employees.ReportsTo = Managers.EmployeeID inner join Orders ON Employees.EmployeeID = Orders.EmployeeID
Group By CONCAT(Employees.FirstName, ' ', Employees.LastName), CONCAT(Managers.FirstName, ' ', Managers.LastName)
Order By COUNT(Orders.OrderID) DESC



--14 
select Customers.ContactName from Customers left join Orders on Orders.CustomerID = Customers.CustomerID where Orders.OrderID is NUll

--15
select Employees.TitleOfCourtesy + Employees.FirstName+ Employees.LastName as employee_name, Customers.ContactName from Employees Cross join Customers




