--1
select ContactName from customers where not exists (select * from orders where 
orders.CustomerID=Customers.CustomerID)
--2
Select * from [Order Details],Products where [Order Details].ProductID=Products.ProductID and Products.CategoryID not in(SELECT Categories.CategoryID FROM Categories
where Products.CategoryID= Categories.CategoryID and (Categories.CategoryName = 'Meat/Poultry' or Categories.CategoryName= 'Dairy Products') )
--3
SELECT TOP 1 Employees.EmployeeID FROM Employees WHERE Employees.EmployeeID IN (SELECT EmployeeID FROM Orders WHERE YEAR(Orders.OrderDate) = 1997)
--4
SELECT Employees.EmployeeID FROM Employees WHERE Employees.ReportsTo IN ( SELECT Employees.EmployeeID FROM Employees WHERE Employees.ReportsTo IS NULL)

--5
select Distinct EmployeeID from EmployeeTerritories where EmployeeTerritories.TerritoryID in ( select territories.TerritoryID from Territories, Region 
where Region.RegionID = Territories.RegionID and Region.RegionDescription = 'Western')

--6
SELECT DISTINCT EmployeeID FROM EmployeeTerritories WHERE EmployeeTerritories.TerritoryID IN (SELECT TerritoryID FROM Territories, Region
WHERE Region.RegionID = Territories.RegionID AND NOT Region.RegionDescription = 'Western')

--7
SELECT Orders.* FROM Orders WHERE Orders.EmployeeID NOT IN (SELECT EmployeeTerritories.EmployeeID FROM EmployeeTerritories
 INNER JOIN Territories ON EmployeeTerritories.TerritoryID = Territories.TerritoryID
 INNER JOIN Region ON Territories.RegionID = Region.RegionID WHERE Region.RegionDescription = 'Western')

 --8
 select Customers.ContactName from Customers where Customers.country = 'USA' Union Select Suppliers.ContactName from Suppliers where Suppliers.Country = 'USA'

 --9
 SELECT TOP 1 ProductName FROM Products ORDER BY UnitPrice ASC

 --10
 Select EmployeeID, CASE
WHEN year(GETDATE() - HireDate) > 5 THEN 3
WHEN year(GETDATE() - HireDate) < 5 and year(GETDATE() - HireDate) > 3 THEN 2
WHEN year(GETDATE() - HireDate) < 3 THEN 1
END AS SeniorityLevel From employees

--11
Select ProductName, CASE
WHEN unitprice > 80 THEN 'Costly'
WHEN unitprice > 30 and unitprice < 80 THEN 'Economical' Else 'Cheap' END AS Types from Products