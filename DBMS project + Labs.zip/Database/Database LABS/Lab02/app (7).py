
from PyQt6.QtWidgets import QMainWindow, QApplication, QTableWidgetItem, QLineEdit, QRadioButton, QCheckBox
from PyQt6 import QtWidgets, uic
from PyQt6.QtCore import Qt 
from PyQt6.QtWidgets import QMessageBox
import sys

books = [
    ["0201144719 9780201144710", "An introduction to database systems", "Database", "Reference Book", "True"],
    ["0805301453 9780805301458", "Fundamentals of database systems", "Database", "Reference Book", "False"],
    ["1571690867 9781571690869", "Object oriented programming in Java", "OOP", "Text Book", "False"],
    ["1842652478 9781842652473", "Object oriented programming using C++", "OOP", "Text Book", "False"],
    ["0070522618 9780070522619", "Artificial intelligence", "AI", "Journal", "False"],
    ["0865760047 9780865760042", "The Handbook of artificial intelligence", "AI", "Journal", "False"],
]

class UI(QtWidgets.QMainWindow):
    def __init__(self):
        super(UI, self).__init__() 
        uic.loadUi('Lab2.ui', self) 
        self.booksTableWidget.setRowCount(len(books))
        for i in range(len(books)):
            for j in range(5):
                item = QtWidgets.QTableWidgetItem(books[i][j])
                item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable) 
                self.booksTableWidget.setItem(i, j, item)
        
        self.pushButton.clicked.connect(self.search)
        self.pushButton_2.clicked.connect(self.view)
        self.pushButton_3.clicked.connect(self.delete)
        self.pushButton_4.clicked.connect(self.close)
       
    def search(self):
        self.booksTableWidget.setRowCount(0)
        title = self.textEdit_2.toPlainText()
        category = self.comboBox.currentText()  
        issued = self.checkBox.isChecked()  
        if self.radioButton.isChecked():
            selected_type = self.radioButton.text()
        elif self.radioButton_2.isChecked():
            selected_type = self.radioButton_2.text()
        elif self.radioButton_3.isChecked():
            selected_type = self.radioButton_3.text()
        else:
            selected_type = None  
        for book in books:
            isbn, book_title, book_category, book_type, is_issued = book
            if (not title or title.lower() in book_title.lower()) and \
            (not category or category == book_category) and \
            (not selected_type or selected_type == book_type) and \
            (not issued or (issued and is_issued.lower() == 'true')):
                row_position = self.booksTableWidget.rowCount()
                self.booksTableWidget.insertRow(row_position)
                self.booksTableWidget.setItem(row_position, 0, QtWidgets.QTableWidgetItem(isbn))
                self.booksTableWidget.setItem(row_position, 1, QtWidgets.QTableWidgetItem(book_title))
                self.booksTableWidget.setItem(row_position, 2, QtWidgets.QTableWidgetItem(book_category))
                self.booksTableWidget.setItem(row_position, 3, QtWidgets.QTableWidgetItem(book_type))
                self.booksTableWidget.setItem(row_position, 4, QtWidgets.QTableWidgetItem(is_issued))

                
    def view(self):
        index = self.booksTableWidget.currentRow()
        if index >= 0:
            isbn = books[index][0]
            title_1 = books[index][1]
            category = books[index][2]
            type1 = books[index][3]
            issuebox = books[index][4]
            # self.view_form = ViewBook(isbn, title_1, category, type1, issuebox)
            # self.view_form.show()
            self.view_b = ViewBook(isbn, title_1, category, type1, issuebox)
            self.view_b.show()
    def delete(self):
        row = self.booksTableWidget.currentRow()
        selected_items = self.booksTableWidget.selectedItems()
        if selected_items:
            book_title = self.booksTableWidget.item(row, 1).text()
            confirmation = QMessageBox.question(self, "Confirm Deletion",
                                                f"Are you sure you want to delete the book:\n{book_title}?",
                                                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                                QMessageBox.StandardButton.No)
            if confirmation == QMessageBox.StandardButton.Yes:
                self.booksTableWidget.removeRow(row)
                QtWidgets.QMessageBox.information(self, "Deleted", "Book has been deleted.")
            else:
                QtWidgets.QMessageBox.information(self, "Cancelled", "Deletion was cancelled.")
                
    def close(self):
        exit()

class ViewBook(QtWidgets.QMainWindow):
    def __init__(self, isbn, title_1, category, type1, issuebox):
        super().__init__()
        uic.loadUi('view_b.ui', self)
        self.isbn = isbn
        self.titlemain = title_1
        self.category = category
        self.typer = type1

        self.isbnview = self.findChild(QLineEdit, 'lineEdit')
        self.isbnview.setText(self.isbn)
        self.isbnview.setDisabled(True)

        self.titleview = self.findChild(QLineEdit, 'lineEdit_2')
        self.titleview.setText(self.titlemain)
        self.titleview.setDisabled(True)

        self.categoryview = self.findChild(QLineEdit, 'lineEdit_3')
        self.categoryview.setText(self.category)
        self.categoryview.setDisabled(True)

        self.referencebox = self.findChild(QRadioButton, 'radioButton')
        self.textbutton = self.findChild(QRadioButton, 'radioButton_2')
        self.journalbutton = self.findChild(QRadioButton, 'radioButton_3')

        self.referencebox.setEnabled(False)
        self.textbutton.setEnabled(False)
        self.journalbutton.setEnabled(False)

        if type1 == 'Reference Book':
            self.referencebox.setChecked(True)
        elif type1 == 'Text Book':
            self.textbutton.setChecked(True)
        elif type1 == 'Journal':
            self.journalbutton.setChecked(True)

        self.issuedbox = self.findChild(QCheckBox, "issuedLabel")
        if self.issuedbox is not None:
            self.issuedbox.setEnabled(False)
            if issuebox == 'True':
                self.issuedbox.setChecked(True)
            elif issuebox == 'False':
                self.issuedbox.setChecked(False)

app = QtWidgets.QApplication(sys.argv)
window = UI()
window.show()
app.exec()







