#include "RBT.hpp"


template<class T>
RBTNode<T>::RBTNode(const T& data) : data(data), color(RED), left(nullptr), right(nullptr), parent(nullptr) {}

template <class T>
RBTNode<T>* RBTNode<T>::sibling(){
	// sibling null if no parent
	if (parent == NULL)
	return NULL;

	if (this == parent->left)
	return parent->right;

	return parent->left;
}

// Constructor for RedBlackTree
template<class T>
RedBlackTree<T>::RedBlackTree() : root(nullptr) {}

// Destructor
template<class T>
RedBlackTree<T>::~RedBlackTree() {
}

// Left Rotation
template<class T>
void RedBlackTree<T>::rotateLeft(RBTNode<T>* x) {
    RBTNode<T>* y = x->right;
    x->right = y->left;
    if (y->left != nullptr)
        y->left->parent = x;
    y->parent = x->parent;
    if (x->parent == nullptr)
        root = y;
    else if (x == x->parent->left)
        x->parent->left = y;
    else
        x->parent->right = y;
    y->left = x;
    x->parent = y;
}

// Right Rotation
template<class T>
void RedBlackTree<T>::rotateRight(RBTNode<T>* x) {
    RBTNode<T>* y = x->left;
    x->left = y->right;
    if (y->right != nullptr)
        y->right->parent = x;
    y->parent = x->parent;
    if (x->parent == nullptr)
        root = y;
    else if (x == x->parent->right)
        x->parent->right = y;
    else
        x->parent->left = y;
    y->right = x;
    x->parent = y;
}

// Fix Violation after Insertion
template<class T>
void RedBlackTree<T>::fixViolation(RBTNode<T>* x) {
    RBTNode<T>* parent = nullptr;
    RBTNode<T>* grandparent = nullptr;
    while ((x != root) && (x->color != BLACK) && (x->parent->color == RED)) {
        parent = x->parent;
        grandparent = x->parent->parent;
        if (parent == grandparent->left) {
            RBTNode<T>* uncle = grandparent->right;
            if (uncle != nullptr && uncle->color == RED) {
                grandparent->color = RED;
                parent->color = BLACK;
                uncle->color = BLACK;
                x = grandparent;
            } else {
                if (x == parent->right) {
                    rotateLeft(parent);
                    x = parent;
                    parent = x->parent;
                }
                rotateRight(grandparent);
                swap(parent->color, grandparent->color);
                x = parent;
            }
        } else {
            RBTNode<T>* uncle = grandparent->left;
            if ((uncle != nullptr) && (uncle->color == RED)) {
                grandparent->color = RED;
                parent->color = BLACK;
                uncle->color = BLACK;
                x = grandparent;
            } else {
                if (x == parent->left) {
                    rotateRight(parent);
                    x = parent;
                    parent = x->parent;
                }
                rotateLeft(grandparent);
                swap(parent->color, grandparent->color);
                x = parent;
            }
        }
    }
    root->color = BLACK;
}

// Insert a new node
template<class T>
void RedBlackTree<T>::insert(const T& data) {
    RBTNode<T>* node = new RBTNode<T>(data);
    insertHelper(node);
}

// Insert Helper function
template<class T>
void RedBlackTree<T>::insertHelper(RBTNode<T>* z) {
    RBTNode<T>* x = root;
    RBTNode<T>* y = nullptr;
    while (x != nullptr) {
        y = x;
        if (z->data < x->data)
            x = x->left;
        else if (z->data > x->data)
            x = x->right;
        else {
            std::cout << "ID " << z->data << " already exists in the tree." << std::endl;
            delete z; // Delete the duplicate node
            return;
        }
    }
    z->parent = y;
    if (y == nullptr)
        root = z;
    else if (z->data < y->data)
        y->left = z;
    else
        y->right = z;
    z->color = RED; // New nodes are initially colored red
    fixViolation(z); // Fix any violations after insertion
}

// Search for a Node in the tree
template<class T>
RBTNode<T>* RedBlackTree<T>::searchTree(const T& key) {
    return searchTreeHelper(root, key);
}

// Search Tree Helper function
template<class T>
RBTNode<T>* RedBlackTree<T>::searchTreeHelper(RBTNode<T>* node, const T& key) {
    if (node == nullptr || node->data == key)
        return node;
    if (key < node->data)
        return searchTreeHelper(node->left, key);
    return searchTreeHelper(node->right, key);
}

// Delete a Node from the tree
template<class T>
void RedBlackTree<T>::deleteNode(const T &data) {
	if (root == NULL)
	// Tree is empty
	return;

	RBTNode<T> *v = searchTree(data), *u;

	if (v->data != data) {
	std::cout << "No node found to delete with value:" << data << std::endl;
	return;
	}

	deleteNodeHelper(v);
}

template <class T>
RBTNode<T>* RedBlackTree<T>::replace(RBTNode<T> *x) {
	// when node have 2 children
	if (x->left != NULL and x->right != NULL){
        RBTNode<T> *temp = x->right;

        while (temp->left != NULL)
        temp = temp->left;

        return temp;
    }

	// when leaf
	if (x->left == NULL and x->right == NULL)
	return NULL;

	// when single child
	if (x->left != NULL)
	return x->left;
	else
	return x->right;
}


template <class T>
void RedBlackTree<T>::swapValues(RBTNode<T> *u, RBTNode<T> *v) {
	T temp;
	temp = u->data;
	u->data = v->data;
	v->data = temp;
}


// Delete Node Helper function
template<class T>
void RedBlackTree<T>::deleteNodeHelper(RBTNode<T>* v) {
	RBTNode<T> *u = replace(v);

	// True when u and v are both black
	bool uvBlack = ((u == NULL or u->color == BLACK) && (v->color == BLACK));
	RBTNode<T> *parent = v->parent;

	if (u == NULL) {
	// u is NULL therefore v is leaf
	if (v == root) {
		// v is root, making root null
		root = NULL;
	} else {
		if (uvBlack) {
		// u and v both black
		// v is leaf, fix double black at v
		fixDoubleBlack(v);
		} else {
		// u or v is red
		if (v->sibling() != NULL)
			// sibling is not null, make it red"
			v->sibling()->color = RED;
		}

		// delete v from the tree
		if (v == v->parent->left) {
		parent->left = NULL;
		} else {
		parent->right = NULL;
		}
	}
	delete v;
	return;
	}

	if (v->left == NULL || v->right == NULL) {
	// v has 1 child
	if (v == root) {
		// v is root, assign the value of u to v, and delete u
		v->data = u->data;
		v->left = v->right = NULL;
		delete u;
	} else {
		// Detach v from tree and move u up
		if (v == v->parent->left) {
		parent->left = u;
		} else {
		parent->right = u;
		}
		delete v;
		u->parent = parent;
		if (uvBlack) {
		// u and v both black, fix double black at u
		fixDoubleBlack(u);
		} else {
		// u or v red, color u black
		u->color = BLACK;
		}
	}
	return;
	}

	// v has 2 children, swap values with successor and recurse
	swapValues(u, v);
	deleteNodeHelper(u);
}

// Fix Double Black
template<class T>
void RedBlackTree<T>::fixDoubleBlack(RBTNode<T> *x) {
	if (x == root)
	// Reached root
	return;

	RBTNode<T> *sibling = x->sibling(), *parent = x->parent;
	if (sibling == NULL) {
	// No sibling, double black pushed up
	fixDoubleBlack(parent);
	} else {
	if (sibling->color == RED) {
		// Sibling red
		parent->color = RED;
		sibling->color = BLACK;
		if (sibling == sibling->parent->left) {
		// left case
		rotateRight(parent);
		} else {
		// right case
		rotateLeft(parent);
		}
		fixDoubleBlack(x);
	} else {
		// Sibling black
		if ((sibling->left != nullptr && sibling->left->color == RED) || (sibling->right != nullptr && sibling->right->color == RED)) {
		// at least 1 red children
		if (sibling->left != nullptr && sibling->left->color == RED) {
			if (sibling == sibling->parent->left) {
			// left left
			sibling->left->color = sibling->color;
			sibling->color = parent->color;
			rotateRight(parent);
			} else {
			// right left
			sibling->left->color = parent->color;
			rotateRight(sibling);
			rotateLeft(parent);
			}
		} else {
			if (sibling == sibling->parent->left) {
			// left right
			sibling->right->color = parent->color;
			rotateLeft(sibling);
			rotateRight(parent);
			} else {
			// right right
			sibling->right->color = sibling->color;
			sibling->color = parent->color;
			rotateLeft(parent);
			}
		}
		parent->color = BLACK;
		} else {
		// 2 black children
		sibling->color = RED;
		if (parent->color == BLACK)
			fixDoubleBlack(parent);
		else
			parent->color = BLACK;
		}
	}
	}
}

// Read data from a file and insert into the tree
template<class T>
void RedBlackTree<T>::readDataFromFile(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }
    T value;
    while (file >> value) {
        insert(value);
    }
    file.close();
}

// Save tree to a file
template<class T>
void RedBlackTree<T>::saveTreeToFile(const std::string& filename) {
    std::ofstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        return;
    }
    saveTreeHelper(root, file);
    file.close();
}

// Save Tree Helper function
template<class T>
void RedBlackTree<T>::saveTreeHelper(RBTNode<T>* node, std::ofstream& file) {
    if (node == nullptr)
        return;
    saveTreeHelper(node->left, file);
    file << node->data << std::endl;
    saveTreeHelper(node->right, file);
}

// Get height of the tree
template<class T>
int RedBlackTree<T>::getHeight() {
    return getHeightHelper(root);
}

// Get height helper function
template<class T>
int RedBlackTree<T>::getHeightHelper(RBTNode<T>* node) {
    if (node == nullptr) {
        return 0;
    } else {
        int leftHeight = getHeightHelper(node->left);
        int rightHeight = getHeightHelper(node->right);
        return 1 + std::max(leftHeight, rightHeight);
    }
}




















// #include "RBT.hpp"

// // Constructor for Node
// template<class T>
// RBTNode<T>::RBTNode(const T& data) : data(data), color(RED), left(nullptr), right(nullptr), parent(nullptr) {}

// // Constructor for RedBlackTree
// template<class T>
// RedBlackTree<T>::RedBlackTree() : root(nullptr) {}

// // Destructor
// template<class T>
// RedBlackTree<T>::~RedBlackTree() {
//     deleteTree();
// }

// // Left Rotation
// template<class T>
// void RedBlackTree<T>::rotateLeft(RBTNode<T>* x) {
//     RBTNode<T>* y = x->right;
//     x->right = y->left;
//     if (y->left != nullptr)
//         y->left->parent = x;
//     y->parent = x->parent;
//     if (x->parent == nullptr)
//         root = y;
//     else if (x == x->parent->left)
//         x->parent->left = y;
//     else
//         x->parent->right = y;
//     y->left = x;
//     x->parent = y;
// }

// // Right Rotation
// template<class T>
// void RedBlackTree<T>::rotateRight(RBTNode<T>* x) {
//     RBTNode<T>* y = x->left;
//     x->left = y->right;
//     if (y->right != nullptr)
//         y->right->parent = x;
//     y->parent = x->parent;
//     if (x->parent == nullptr)
//         root = y;
//     else if (x == x->parent->right)
//         x->parent->right = y;
//     else
//         x->parent->left = y;
//     y->right = x;
//     x->parent = y;
// }

// // Fix Violation after Insertion
// template<class T>
// void RedBlackTree<T>::fixViolation(RBTNode<T>* x) {
//     RBTNode<T>* parent = nullptr;
//     RBTNode<T>* grandparent = nullptr;
//     while ((x != root) && (x->color != BLACK) && (x->parent->color == RED)) {
//         parent = x->parent;
//         grandparent = x->parent->parent;
//         if (parent == grandparent->left) {
//             RBTNode<T>* uncle = grandparent->right;
//             if (uncle != nullptr && uncle->color == RED) {
//                 grandparent->color = RED;
//                 parent->color = BLACK;
//                 uncle->color = BLACK;
//                 x = grandparent;
//             } else {
//                 if (x == parent->right) {
//                     rotateLeft(parent);
//                     x = parent;
//                     parent = x->parent;
//                 }
//                 rotateRight(grandparent);
//                 std::swap(parent->color, grandparent->color);
//                 x = parent;
//             }
//         } else {
//             RBTNode<T>* uncle = grandparent->left;
//             if ((uncle != nullptr) && (uncle->color == RED)) {
//                 grandparent->color = RED;
//                 parent->color = BLACK;
//                 uncle->color = BLACK;
//                 x = grandparent;
//             } else {
//                 if (x == parent->left) {
//                     rotateRight(parent);
//                     x = parent;
//                     parent = x->parent;
//                 }
//                 rotateLeft(grandparent);
//                 std::swap(parent->color, grandparent->color);
//                 x = parent;
//             }
//         }
//     }
//     root->color = BLACK;
// }

// // Insert a new node
// template<class T>
// void RedBlackTree<T>::insert(const T& data) {
//     RBTNode<T>* node = new RBTNode<T>(data);
//     insertHelper(node);
// }

// // // Insert Helper function
// // template<class T>
// // void RedBlackTree<T>::insertHelper(Node<T>* z) {
// //     Node<T>* x = root;
// //     Node<T>* y = nullptr;
// //     while (x != nullptr) {
// //         y = x;
// //         if (z->data < x->data)
// //             x = x->left;
// //         else
// //             x = x->right;
// //     }
// //     z->parent = y;
// //     if (y == nullptr)
// //         root = z;
// //     else if (z->data < y->data)
// //         y->left = z;
// //     else
// //         y->right = z;
// //     fixViolation(z);
// // }

// // Insert Helper function
// template<class T>
// void RedBlackTree<T>::insertHelper(RBTNode<T>* z) {
//     RBTNode<T>* x = root;
//     RBTNode<T>* y = nullptr;
//     while (x != nullptr) {
//         y = x;
//         if (z->data < x->data)
//             x = x->left;
//         else if (z->data > x->data)
//             x = x->right;
//         else {
//             std::cout << "ID " << z->data << " already exists in the tree." << std::endl;
//             delete z; // Delete the duplicate node
//             return;
//         }
//     }
//     z->parent = y;
//     if (y == nullptr)
//         root = z;
//     else if (z->data < y->data)
//         y->left = z;
//     else
//         y->right = z;
//     z->color = RED; // New nodes are initially colored red
//     fixViolation(z); // Fix any violations after insertion
// }


// // Inorder Traversal
// template<class T>
// void RedBlackTree<T>::inorder() {
//     inorderHelper(root);
// }

// // Inorder Traversal Helper function
// template<class T>
// void RedBlackTree<T>::inorderHelper(RBTNode<T>* x) {
//     if (x != nullptr) {
//         inorderHelper(x->left);
//         //std::cout << x->data << " ";
//         inorderHelper(x->right);
//     }
// }

// // Find the Node with minimum value
// template<class T>
// RBTNode<T>* RedBlackTree<T>::minValueNode(RBTNode<T>* node) {
//     RBTNode<T>* current = node;
//     while (current->left != nullptr)
//         current = current->left;
//     return current;
// }

// // Search for a Node in the tree
// template<class T>
// RBTNode<T>* RedBlackTree<T>::searchTree(const T& key) {
//     return searchTreeHelper(root, key);
// }

// // Search Tree Helper function
// template<class T>
// RBTNode<T>* RedBlackTree<T>::searchTreeHelper(RBTNode<T>* node, const T& key) {
//     if (node == nullptr || node->data == key)
//         return node;
//     if (key < node->data)
//         return searchTreeHelper(node->left, key);
//     return searchTreeHelper(node->right, key);
// }

// // Delete a Node from the tree
// template<class T>
// void RedBlackTree<T>::deleteNode(const T& data) {
//     deleteNodeHelper(root, data);
// }

// // Delete Node Helper function
// template<class T>
// void RedBlackTree<T>::deleteNodeHelper(RBTNode<T>* node, const T& key) {
//     RBTNode<T>* z = searchTreeHelper(root, key);
//     if (z == nullptr) {
//         std::cout << "Key not found in the tree\n";
//         return;
//     }
//     RBTNode<T>* x;
//     RBTNode<T>* y = z;
//     Color yOriginalColor = y->color;
//     if (z->left == nullptr) {
//         x = z->right;
//         transplant(z, z->right);
//     } else if (z->right == nullptr) {
//         x = z->left;
//         transplant(z, z->left);
//     } else {
//         y = minValueNode(z->right);
//         yOriginalColor = y->color;
//         x = y->right;
//         if (y->parent == z)
//             x->parent = y;
//         else {
//             transplant(y, y->right);
//             y->right = z->right;
//             y->right->parent = y;
//         }
//         transplant(z, y);
//         y->left = z->left;
//         y->left->parent = y;
//         y->color = z->color;
//     }
//     delete z;
//     if (yOriginalColor == BLACK)
//         fixDoubleBlack(x);
// }

// // Fix Double Black
// template<class T>
// void RedBlackTree<T>::fixDoubleBlack(RBTNode<T>* x) {
//     if (x == root)
//         return;
//     RBTNode<T>* sibling = nullptr;
//     while (x != root && x->color == BLACK) {
//         if (x == x->parent->left) {
//             sibling = x->parent->right;
//             if (sibling->color == RED) {
//                 sibling->color = BLACK;
//                 x->parent->color = RED;
//                 rotateLeft(x->parent);
//                 sibling = x->parent->right;
//             }
//             if (sibling->left->color == BLACK && sibling->right->color == BLACK) {
//                 sibling->color = RED;
//                 x = x->parent;
//             } else {
//                 if (sibling->right->color == BLACK) {
//                     sibling->left->color = BLACK;
//                     sibling->color = RED;
//                     rotateRight(sibling);
//                     sibling = x->parent->right;
//                 }
//                 sibling->color = x->parent->color;
//                 x->parent->color = BLACK;
//                 sibling->right->color = BLACK;
//                 rotateLeft(x->parent);
//                 x = root;
//             }
//         } else {
//             sibling = x->parent->left;
//             if (sibling->color == RED) {
//                 sibling->color = BLACK;
//                 x->parent->color = RED;
//                 rotateRight(x->parent);
//                 sibling = x->parent->left;
//             }
//             if (sibling->right->color == BLACK && sibling->left->color == BLACK) {
//                 sibling->color = RED;
//                 x = x->parent;
//             } else {
//                 if (sibling->left->color == BLACK) {
//                     sibling->right->color = BLACK;
//                     sibling->color = RED;
//                     rotateLeft(sibling);
//                     sibling = x->parent->left;
//                 }
//                 sibling->color = x->parent->color;
//                 x->parent->color = BLACK;
//                 sibling->left->color = BLACK;
//                 rotateRight(x->parent);
//                 x = root;
//             }
//         }
//     }
//     x->color = BLACK;
// }

// // Transplant
// template<class T>
// void RedBlackTree<T>::transplant(RBTNode<T>* u, RBTNode<T>* v) {
//     if (u->parent == nullptr)
//         root = v;
//     else if (u == u->parent->left)
//         u->parent->left = v;
//     else
//         u->parent->right = v;
//     if (v != nullptr)
//         v->parent = u->parent;
// }

// // Delete the entire tree
// template<class T>
// void RedBlackTree<T>::deleteTree() {
//     deleteTreeHelper(root);
//     root = nullptr;
// }

// // Delete Tree Helper function
// template<class T>
// void RedBlackTree<T>::deleteTreeHelper(RBTNode<T>* node) {
//     if (node == nullptr)
//         return;
//     deleteTreeHelper(node->left);
//     deleteTreeHelper(node->right);
//     delete node;
// }

// // Read data from a file and insert into the tree
// template<class T>
// void RedBlackTree<T>::readDataFromFile(const std::string& filename) {
//     std::ifstream file(filename);
//     if (!file.is_open()) {
//         std::cerr << "Error opening file: " << filename << std::endl;
//         return;
//     }
//     T value;
//     while (file >> value) {
//         insert(value);
//     }
//     file.close();
// }

// // Save tree to a file
// template<class T>
// void RedBlackTree<T>::saveTreeToFile(const std::string& filename) {
//     std::ofstream file(filename);
//     if (!file.is_open()) {
//         std::cerr << "Error opening file: " << filename << std::endl;
//         return;
//     }
//     saveTreeHelper(root, file);
//     file.close();
// }

// // Save Tree Helper function
// template<class T>
// void RedBlackTree<T>::saveTreeHelper(RBTNode<T>* node, std::ofstream& file) {
//     if (node == nullptr)
//         return;
//     saveTreeHelper(node->left, file);
//     file << node->data << std::endl;
//     saveTreeHelper(node->right, file);
// }


// // int main() {
// //     RedBlackTree<int> rbt;

// //     std::ifstream file("Car_Data.csv"); // Open file
// //     if (!file.is_open()) {
// //         std::cerr << "Error opening file: " << "Car_Data.csv" << std::endl;
// //         return 1; // Exit with error if file not opened
// //     }

// //     std::string line;
// //     // Read each line from the file
// //     while (std::getline(file, line)) {
// //         std::stringstream ss(line);
// //         int id;
// //         // Read each field separated by commas
// //         ss >> id;
// //         rbt.insert(id);
// //     }

// //     file.close();

// //     // Test some operations on the Red-Black Tree
// //     std::cout << "Inorder traversal after insertion: ";
// //     rbt.inorder();
// //     std::cout << std::endl;

// //     int searchValue = 20;
// //     std::cout << "Searching for value " << searchValue << " in the tree: ";
// //     if (rbt.searchTree(searchValue) != nullptr) {
// //         std::cout << "Found value " << searchValue << std::endl;
// //     } else {
// //         std::cout << "Value " << searchValue << " not found" << std::endl;
// //     }

// //     int deleteValue = 10;
// //     std::cout << "Deleting value " << deleteValue << " from the tree" << std::endl;
// //     rbt.deleteNode(deleteValue);

// //     std::cout << "Inorder traversal after deletion: ";
// //     rbt.inorder();
// //     std::cout << std::endl;

// //     return 0;
// // }

