#ifndef RED_BLACK_TREE_HPP
#define RED_BLACK_TREE_HPP
#pragma once
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <chrono>

using namespace std;

enum Color { RED, BLACK };

template<class T>
struct RBTNode {
    T data;
    Color color;
    RBTNode* left;
    RBTNode* right;
    RBTNode* parent;

    RBTNode(const T& data);

    RBTNode* sibling();
};

template<class T>
class RedBlackTree {
private:
    RBTNode<T>* root;

    void rotateLeft(RBTNode<T>* x);
    void rotateRight(RBTNode<T>* x);
    void fixViolation(RBTNode<T>* x);
    void insertHelper(RBTNode<T>* z);
    void deleteNodeHelper(RBTNode<T>* v);
    void swapValues(RBTNode<T> *u, RBTNode<T> *v);
    void fixDoubleBlack(RBTNode<T>* x);
    RBTNode<T>* replace(RBTNode<T> *x);
    RBTNode<T>* searchTreeHelper(RBTNode<T>* node, const T& key);
    void saveTreeHelper(RBTNode<T>* node, std::ofstream& file);
    int getHeightHelper(RBTNode<T>* node); // Added for height calculation

public:
    RedBlackTree();
    ~RedBlackTree();
    void insert(const T& data);
    void deleteNode(const T& data);
    RBTNode<T>* searchTree(const T& key);
    int getHeight(); // Added for height calculation
    void readDataFromFile(const std::string& filename);
    void saveTreeToFile(const std::string& filename);
};

#endif























// #ifndef RED_BLACK_TREE_HPP
// #define RED_BLACK_TREE_HPP
// #pragma once
// #include <iostream>
// #include <fstream>
// #include <sstream>
// #include <string>
// #include <chrono>

// enum Color { RED, BLACK };

// template<class T>
// struct RBTNode {
//     T data;
//     Color color;
//     RBTNode* left;
//     RBTNode* right;
//     RBTNode* parent;

//     RBTNode(const T& data);
// };

// template<class T>
// class RedBlackTree {
// private:
//     RBTNode<T>* root;

//     void rotateLeft(RBTNode<T>* x);
//     void rotateRight(RBTNode<T>* x);
//     void fixViolation(RBTNode<T>* x);
//     void insertHelper(RBTNode<T>* z);
//     void inorderHelper(RBTNode<T>* x);
//     RBTNode<T>* minValueNode(RBTNode<T>* node);
//     void deleteNodeHelper(RBTNode<T>* node, const T& key);
//     void fixDoubleBlack(RBTNode<T>* x);
//     RBTNode<T>* searchTreeHelper(RBTNode<T>* node, const T& key);
//     void deleteTreeHelper(RBTNode<T>* node);
//     void saveTreeHelper(RBTNode<T>* node, std::ofstream& file);

// public:
//     RedBlackTree();
//     ~RedBlackTree();
//     void insert(const T& data);
//     void deleteNode(const T& data);
//     void inorder();
//     RBTNode<T>* searchTree(const T& key);
//     void transplant(RBTNode<T>* u, RBTNode<T>* v);
//     void deleteTree();
//     void readDataFromFile(const std::string& filename);
//     void saveTreeToFile(const std::string& filename);
// };

// #endif