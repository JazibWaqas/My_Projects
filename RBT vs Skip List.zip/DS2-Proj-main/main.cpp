#include "plots\pbPlots.cpp"
#include "plots\supportLib.cpp"
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include "RBT.hpp"
#include "RBT.cpp"
#include "SkipList.cpp"
#include "SkipList.hpp"
#include <chrono>
#include <random>

using namespace std;

void outputFile(const string &filename, double insertTimeRBT, double insertTimeSL, double deleteTimeRBT, double deleteTimeSL, double searchTimeRBT, double searchTimeSL) {
 
    std::ofstream outputFile(filename, ios_base::out | ios_base::app);
    if (!outputFile.is_open()) {
        cerr << "Error opening output file: " << filename << endl;
        return;
    }

    outputFile << fixed << setprecision(6) << insertTimeRBT << "," << insertTimeSL << "," << searchTimeRBT << "," << searchTimeSL << "," << deleteTimeRBT << "," << deleteTimeSL << endl;
    outputFile.close();
}


int draw_multi_line_graph(
	vector<double> xsa, 
	vector<double> ysa, 
	vector<double> xs, 
	vector<double> ys,
	std::string filename, 
	std::vector<wchar_t>* graph_title
	)
{
	bool success;
	StringReference *errorMessage = CreateStringReferenceLengthValue(0, L' ');
	RGBABitmapImageReference *imageReference = CreateRGBABitmapImageReference();
	ScatterPlotSeries *series = GetDefaultScatterPlotSeriesSettings();
	series->xs = &xs;
	series->ys = &ys;
	series->linearInterpolation = true;
	series->lineType = toVector(L"solid");
	series->lineThickness = 2;
	series->color = CreateRGBColor(1, 0, 0);
	ScatterPlotSeries *series2 = GetDefaultScatterPlotSeriesSettings();
	series2->xs = &xsa;
	series2->ys = &ysa;
	series2->linearInterpolation = true;
	series2->lineType = toVector(L"solid");
	series2->lineThickness = 2;
	series2->color = CreateRGBColor(0, 0, 1);
	ScatterPlotSettings *settings = GetDefaultScatterPlotSettings();
	settings->width = 600;
	settings->height = 400;
	settings->autoBoundaries = true;
	settings->autoPadding = true;
	settings->title = graph_title; //toVector(L"");
	settings->yLabel = toVector(L"Time (seconds)");
	settings->xLabel = toVector(L"Data size");
	settings->scatterPlotSeries->push_back(series);
	settings->scatterPlotSeries->push_back(series2);
	success = DrawScatterPlotFromSettings(imageReference, settings, errorMessage);
	if(success){
		vector<double> *pngdata = ConvertToPNG(imageReference->image);
		WriteToFile(pngdata,filename);
		DeleteImage(imageReference->image);
	}else{
		cerr << "Error: ";
		for(wchar_t c : *errorMessage->string){
			cerr << c;
		}
		cerr << endl;
	}

	FreeAllocations();

	return success ? 0 : 1;
}


void measureTimes(const vector<int> &ids, double &insertTimeRBT, double &insertTimeSL, double &searchTimeRBT, double &searchTimeSL, double &deleteTimeRBT, double &deleteTimeSL) {
    RedBlackTree<int> rbt;
    SkipList<int> sl;

    auto startInsertRBT = chrono::steady_clock::now();
    for (int id : ids) {
        rbt.insert(id);
    }
    auto endInsertRBT = chrono::steady_clock::now();
    insertTimeRBT = chrono::duration<double>(endInsertRBT - startInsertRBT).count();

    auto startInsertSL = chrono::steady_clock::now();
    for (int id : ids) {
        sl.insertNode(id);
    }
    auto endInsertSL = chrono::steady_clock::now();
    insertTimeSL = chrono::duration<double>(endInsertSL - startInsertSL).count();

    auto startSearchRBT = chrono::steady_clock::now();
    for (int id : ids) {
        rbt.searchTree(id);
    }
    auto endSearchRBT = chrono::steady_clock::now();
    searchTimeRBT = chrono::duration<double>(endSearchRBT - startSearchRBT).count();

    auto startSearchSL = chrono::steady_clock::now();
    for (int id : ids) {
        sl.findNode(id);
    }
    auto endSearchSL = chrono::steady_clock::now();
    searchTimeSL = chrono::duration<double>(endSearchSL - startSearchSL).count();

    auto startDeleteRBT = chrono::steady_clock::now();
    for (int id : ids) {
        rbt.deleteNode(id);
    }
    auto endDeleteRBT = chrono::steady_clock::now();
    deleteTimeRBT = chrono::duration<double>(endDeleteRBT - startDeleteRBT).count();

    auto startDeleteSL = chrono::steady_clock::now();
    for (int id : ids) {
        sl.deleteNode(id);
    }
    auto endDeleteSL = chrono::steady_clock::now();
    deleteTimeSL = chrono::duration<double>(endDeleteSL - startDeleteSL).count();
}
int main() {
    vector<string> filenames = {"dataset/Car_Data_1k.csv.csv", "dataset/Car_Data_5k.csv.csv", "dataset/Car_Data_10k.csv.csv", "dataset/Car_Data_20k.csv.csv", "dataset/Car_Data_40k.csv.csv", "dataset/Car_Data_60k.csv.csv", "dataset/Car_Data_80k.csv.csv", "dataset/Car_Data_100k.csv.csv"};
    vector<double> X_datasize = {1000, 5000, 10000, 20000, 40000, 60000, 80000, 100000};
    vector<double> Y_skiplistinsertiontime;
    vector<double> Y_rbtinsertiontime;
    vector<double> Y_skiplistsearchtime;
    vector<double> Y_rbtsearchtime;
    vector<double> Y_skiplistdeletetime;
    vector<double> Y_rbtdeletetime;

    for (const string &filename : filenames) {
        ifstream file(filename);
        if (!file.is_open()) {
            cerr << "Error opening file: " << filename << endl;
            continue;
        }

        string line;
        vector<int> ids;
        int sampleSize = 0;
        double insertTimeRBT = 0, insertTimeSL = 0, searchTimeRBT = 0, searchTimeSL = 0, deleteTimeRBT = 0, deleteTimeSL = 0;
        getline(file, line); // Skip header line
        while (getline(file, line)){
            if (line == "") break;
            sampleSize++;
            insertTimeRBT += stod(line.substr(0, line.find_first_of(',')));
            line = line.substr(line.find_first_of(',')+1, line.size() - line.find_first_of(',')-1);
            insertTimeSL += stod(line.substr(0, line.find_first_of(',')));
            line = line.substr(line.find_first_of(',')+1, line.size() - line.find_first_of(',')-1);
            searchTimeRBT += stod(line.substr(0, line.find_first_of(',')));
            line = line.substr(line.find_first_of(',')+1, line.size() - line.find_first_of(',')-1);
            searchTimeSL += stod(line.substr(0, line.find_first_of(',')));
            line = line.substr(line.find_first_of(',')+1, line.size() - line.find_first_of(',')-1);
            deleteTimeRBT += stod(line.substr(0, line.find_first_of(',')));
            line = line.substr(line.find_first_of(',')+1, line.size() - line.find_first_of(',')-1);
            deleteTimeSL += stod(line);
        }

        insertTimeRBT /= sampleSize; 
        insertTimeSL /= sampleSize;
        searchTimeRBT /= sampleSize;
        searchTimeSL /= sampleSize;
        deleteTimeRBT /= sampleSize;
        deleteTimeSL /= sampleSize;
        
        Y_skiplistinsertiontime.push_back(insertTimeSL);
        Y_rbtinsertiontime.push_back(insertTimeRBT);
        Y_skiplistsearchtime.push_back(searchTimeSL);
        Y_rbtsearchtime.push_back(searchTimeRBT);
        Y_skiplistdeletetime.push_back(deleteTimeSL);
        Y_rbtdeletetime.push_back(deleteTimeRBT);
    }
    draw_multi_line_graph(X_datasize, Y_skiplistinsertiontime, X_datasize, Y_rbtinsertiontime, "insertion_graph.png", toVector(L"SkipList(BLUE)(p=e^-1) V/S RBT (RED) insert"));
    draw_multi_line_graph(X_datasize, Y_skiplistsearchtime, X_datasize, Y_rbtsearchtime, "search_graph.png", toVector(L"SkipList(BLUE)(p=e^-1) V/S RBT (RED) search"));
    draw_multi_line_graph(X_datasize, Y_skiplistdeletetime, X_datasize, Y_rbtdeletetime, "delete_graph.png", toVector(L"SkipList(BLUE)(p=e^-1) V/S RBT (RED) delete"));
    
    // different version of main to load in files to output files
    // vector<string> filenames = {"C:/Users/Shafqat Ali Khan/Documents/GitHub/DS2-Proj/dataset/Car_Data_100k.csv"}; //, "dataset/Car_Data_5k.csv.csv", "dataset/Car_Data_10k.csv.csv", "dataset/Car_Data_20k.csv.csv", "dataset/Car_Data_40k.csv.csv", "dataset/Car_Data_60k.csv.csv", "dataset/Car_Data_80k.csv.csv", "dataset/Car_Data_100k.csv.csv"};
    // for (const string &filename : filenames) {
    //     ifstream file(filename);
    //     if (!file.is_open()) {
    //         cerr << "Error opening file: " << filename << endl;
    //         continue;
    //     }

    //     string line;
    //     vector<int> ids;
    //     getline(file, line); // Skip header line
    //     while (getline(file, line)) {
    //         stringstream ss(line);
    //         int id;
    //         if (ss >> id) {
    //             ids.push_back(id);
    //         }
    //     }
    //     file.close();

    //     double insertTimeRBT, insertTimeSL, deleteTimeRBT, deleteTimeSL, searchTimeRBT, searchTimeSL;
    //     measureTimes(ids, insertTimeRBT, insertTimeSL, searchTimeRBT, searchTimeSL, deleteTimeRBT, deleteTimeSL);
    //     outputFile(filename+".csv", insertTimeRBT, insertTimeSL, searchTimeRBT, searchTimeSL, deleteTimeRBT, deleteTimeSL);
    // }
    
    return 0;
}