#pragma once
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <bits/stdc++.h>
#include <cstdlib>

using namespace std;

template <class T>
struct SLNode{
    T value;
    vector<SLNode*> next;
    int height;
    SLNode();

    SLNode(T v, int h);

    void changeHeight(int h);
};

template <class T>
class SkipList {
private:
    int height;
    SLNode<T>* sentinel;
public:
    SkipList(): height(0), sentinel(new SLNode<T>()) {}

    ~SkipList();
    
    int randomHeight();

    void deleteList();

    T findNode(T x);

    void insertNode(T x);

    void deleteNode(T x);
};