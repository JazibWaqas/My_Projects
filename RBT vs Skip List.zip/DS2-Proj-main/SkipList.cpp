#include "SkipList.hpp"

template <class T>

SLNode<T>::SLNode(): value(0), height(0){
    this->next.resize(1);
    this->next[0] = nullptr;
}

template <class T>

SLNode<T>::SLNode(T v, int h): value(v), height(h){
    this->next.resize(h+1);
    for (int i = 0; i <= h; i++)
        this->next[i] = nullptr;
}

template <class T>

SkipList<T>::~SkipList(){
    deleteList();
}

template <class T>

void SLNode<T>::changeHeight(int h){
    int prevHeight = height;
    height = h;
    std::vector<SLNode*> newNext;
    this->next.resize(h+1);
    for (int i = prevHeight+1; i <= h+1; i++)
        next[i] = nullptr;
}

template <class T>

void SkipList<T>::deleteList(){
    SLNode<T>* u = sentinel;

    while (u != nullptr){
        SLNode<T>* deletionNode = u;
        u = u->next[0];
        delete deletionNode;
    }
}

template <class T>

int SkipList<T>::randomHeight() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_real_distribution<> dist(0.0, 1.0);
    int h = 0;
    while (dist(gen) < exp(-1))
        h++;

    return h;
}

template <class T>

T SkipList<T>::findNode(T x){
    SLNode<T>* u = sentinel;
    int level = height;
    while (level >= 0){
        while (u->height >= level && u->next[level] != nullptr && u->next[level]->value < x){
            u = u->next[level];
        }
        level--;
    }
    if (u->next[0] != nullptr)
        return u->next[0]->value;
    else return u->value;
}

template <class T>

void SkipList<T>::insertNode(T x){
    int h = randomHeight();
    
    SLNode<T>* add = new SLNode<T>(x, h);

    if (h > height){
        height = h;
        sentinel->changeHeight(height+1);
        // sentinel->next.resize(height+1);
    }

    vector<SLNode<T>*> update = sentinel->next;
    SLNode<T>* u = sentinel;
    int level = height;

    while (level >= 0){
        while (u->height >= level && u->next[level] != nullptr && u->next[level]->value < x){
            u = u->next[level];
        }
        update[level] = u;
        level--;
    }

    for (int i = 0; i <= h; i++)
        add->next[i] = update[i]->next[i];
    
    for (int i = 0; i <= h; i++)
        update[i]->next[i] = add;  
}

template <class T>

void SkipList<T>::deleteNode(T x){
    vector<SLNode<T>*> update = sentinel->next;
    SLNode<T>* u = sentinel;
    int level = height;
    while (level >= 0){
        while (u->height >= level && u->next[level] != nullptr && u->next[level]->value < x){
            u = u->next[level];
        }
        update[level] = u;
        level--;
    }
    if (u->next[0] == nullptr || u->next[0]->value != x)
        return;
    
    SLNode<T>* toDelete = u->next[0];
    level = toDelete->height;

    for (int i = 0; i <= level; i++)
        update[i]->next[i] = toDelete->next[i];
    
    while (true){
        if (sentinel->next[height] != nullptr)
            break;
        sentinel->next.resize(height);
        height--;
    }
}

// int main(){
//     SkipList<int> s;

//     std::ifstream file("C:/Users/Shafqat Ali Khan/Documents/GitHub/DS2-Proj/dataset/Car_Data_1k.csv"); // Open file
//     if (!file.is_open()) {
//         std::cerr << "Error opening file: " << "C:/Users/Shafqat Ali Khan/Documents/GitHub/DS2-Proj/dataset/Car_Data_1k.csv" << std::endl;
//         // Return empty vector if file not opened
//     }

//     std::string line;
//     // Read each line from the file
//     std::getline(file, line);
//     while (std::getline(file, line)) {
//         stringstream ss(line);
//         int id;
//         // Read each field separated by commas
//         ss >> id;
//         s.insertNode(id);
//     }

//     return 0;
// }